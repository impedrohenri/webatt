import './Card.css'

export default function Card(props) {
    return (
        <div class="card" style={{ width: 288 }}>
            <img src={props.item.image} class="card-img-top" alt="..." />
            <div class="card-body">
                <h5 class="card-title">{props.item.title}</h5>
                <p class="card-text">Categoria: {props.item.category}</p>
                <p class="card-text">R$: {props.item.price}</p>
            </div>
        </div>
    )
}