import { useEffect, useState } from 'react';
import './App.css';
import Card from './components/card/Card';

function App() {
  const [roupas, setRoupas] = useState([])
  useEffect(() => {
    fetch('https://fakestoreapi.com/products/')
      .then(res => res.json())
      .then(json => {
        console.log(json)
        setRoupas(json)
      }).catch(error => console.error('Erro:', error));
  }, [])
  return (
    <>
    {
    roupas.length == 0 
    ?(<h1>Carregando...</h1>)
    :null
    }
      <div className='d-flex flex-wrap'>
        {roupas.map(roupa => <Card item={roupa} />)}
      </div>
    </>
  );
}

export default App;
